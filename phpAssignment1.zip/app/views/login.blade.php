@extends('master')

@section('content')
    <div class="jumbotron" align="center">
        {{ Form::open(array('url' => 'login')) }}
        <h1>Login</h1>

        <!-- if there are login errors, show them here -->
        <p>
            {{ $errors->first('email') }}
            {{ $errors->first('password') }}
        </p>

        <p>
            {{ Form::label('email', 'Email Address') }}
            {{ Form::text('email', Input::old('email'), array('placeholder' => 'awesome@awesome.com')) }}
        </p>

        <p>
            {{ Form::label('password', 'Password') }}
            {{"&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"}}
            {{ Form::password('password') }}
        </p>

        <p>{{ Form::submit('Login')}}</p>
        <a href="{{ URL::to('register'); }}">Register</a>
        <a href="{{ URL::to('forgotpassword'); }}">Forgot Password</a>

        {{ Form::close() }}
    </div>
@endsection