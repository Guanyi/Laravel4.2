@extends('master')

@section('content')

    <div class="jumbotron" align="center">
        {{ Form::open(array('url' => 'processingregistration'))}}
        <h1>Register</h1>
        <p>
        {{ Form::label('username', 'Email Address')}}
        {{"&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"}}
        {{ Form::text('username', Input::old('username'), array('placeholder' => 'awesome@awesome.com')) }}
        </p>
        <p>
        {{ Form::label('password', 'Password')}}
        {{"&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"}}
        {{ Form::password('password')}}
        </p>
        <p>
        {{ Form::label('password_confirmation', 'Password Confirmation')}}
        {{ Form::password('password_confirmation')}}
        </p>
        {{ Form::submit('Register')}} or
        <a href="{{ URL::to('/'); }}">Login</a>
    </div>

@endsection