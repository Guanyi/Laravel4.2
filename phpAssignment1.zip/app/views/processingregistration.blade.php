<p>
    {{ 'Check your email and click the confirmation link to active your account.' }}
</p>
<a href="{{ URL::to('/'); }}">Login</a>