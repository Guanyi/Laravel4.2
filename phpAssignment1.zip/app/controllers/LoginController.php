<?php

use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\View;


class LoginController extends BaseController {

	public function showLogin()
	{
        return View::make('login');
	}

	public function processLogin()
	{
        $rules = array(
            'email' => 'required|email', // make sure the email is an actual email
            'password' => 'required' // password can only be alphanumeric and has to be greater than 3 characters
        );

        $validator = Validator::make(Input::all(), $rules);

        if ($validator->fails())
            return Redirect::to('/')->withErrors($validator)->withInput(Input::except('password'));

        else {
            $userdata = array(
                'username' => Input::get('email'),
                'password' => Input::get('password')
            );
            // attempt to do the login
            if (Auth::attempt($userdata))
                return View::make('profile');
            else
                return View::make('processlogin')->with('message', 'No match record found.');
        }
	}
}
