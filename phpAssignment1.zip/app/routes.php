<?php

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the Closure to execute when that URI is requested.
|
*/

use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\View;

Route::get('/', 'LoginController@showLogin');

Route::post('login', 'LoginController@processLogin');

Route::get('forgotpassword', function()
{
    return View::make('forgotpassword');
});

Route::get('register', 'RegistrationController@showRegistration');

Route::post('processingregistration', 'RegistrationController@processRegistration');

/*Route::post('login', function() {
    //$data = User::find(4);
    $data = User::all();
    //var_dump($data->username);
    //echo $data->username;

    $input = Input::all();
    //var_dump($input[]);
    $errorno = 0;
    if( $input['email'] == '' )
        $errorno = 1;
    elseif( $input['password'] == '' )
        $errorno = 2;
    elseif( strip_tags( $input['email'] ) != $input['email'] )
        $errorno = 3;
    elseif( strip_tags( $input['password'] ) != $input['password'] )
        $errorno = 4;
    else
        $errorno = 0;

    if( $errorno > 0 )
        return View::make('processlogin')->with('errorno', $errorno);

    foreach($data as $record) {
        //echo "ok";
        if( $input['email'] == $record->username &&  Hash::make($input['password']) == $record->password);
            return View::make('profile');
    }
});*/