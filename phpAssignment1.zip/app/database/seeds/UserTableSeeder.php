<?php

use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;

class UserTableSeeder extends \Illuminate\Database\Seeder{
    public function run() {
        DB::table('users')->delete();

        $users = array(
            array(
                'username' => 'example@example.com',
                'password' => Hash::make('12345'),
                'active' => false,
                'created_at' => date('Y-m-d G:H:s'),
                'updated_at' => date('Y-m-d G:H:s')
            ),

            array(
                'username' => 'test@test.com',
                'password' => Hash::make('abcde'),
                'active' => false,
                'created_at' => date('Y-m-d G:H:s'),
                'updated_at' => date('Y-m-d G:H:s')
            )
        );

        DB::table('users')->insert($users);
    }
}